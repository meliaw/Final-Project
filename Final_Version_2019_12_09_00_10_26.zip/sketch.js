let particles = [];
let video;
let opticalFlow;
let step = 20;
let flowScaleFactor = 0.1;
let w = 640;
let h = 480;
let debug = false;
let screenGrab;
let starryNight;
let lavaLamp;


function setup() {
  createCanvas(windowWidth, windowHeight);
  
  video = createCapture({
      audio: false,
      video: {
          width: w,
          height: h
      }
  });
  video.elt.setAttribute('playsinline', '');
  video.hide();
  
    for (let i = 0; i < 100; i++) {
    
    let particle = new Particle(
      windowWidth / 2 + random(-10, 10),
      windowHeight / 2 + random(-10, 10),
      1,
      100
    );
    
    let force = createVector(0, random(10));
    particle.applyForce(force);
    
    particles.push(particle);
  }
  
  // for (let i = 0; i < 100; i++) {
  //   if ( i < 20) {
  //     particles[i].color = color(26, 66, 91, 75);
  //   } else if ( i < 40) {
  //     particles[i].color = color(198, 202, 116, 75); 
  //   } else if ( i < 60) {
  //     particles[i].color = color(224, 179, 5, 75); 
  //   } else if ( i < 80) {
  //     particles[i].color = color(57, 137, 185, 75);
  //   } else {
  //     particles[i].color = color(121, 164, 158, 75); 
  //   }
  // }
  
  opticalFlow = new OpticalFlow(w, h, step);
  
  starryNight = createButton("Starry Night");
  lavaLamp = createButton('Lava Lamp');
  screenGrab = createButton("Save");
  starryNight.mousePressed(gogh);
  lavaLamp.mousePressed(lava);
  screenGrab.mousePressed(takeScreenshot);
  
}

function draw() {
  //background(220);
  
  
  translate(width,0); // move to far corner
  scale(-1.0,1.0);    // flip x-axis backwards
  
  opticalFlow.update(video);
  
  //image(video, 0, 0, width, height);
  
  if (debug) {
    opticalFlow.debugDraw();
  }
  
  let flow = opticalFlow.getFlow();
  
  for (let i = 0; i < particles.length; i++) {
    let particle = particles[i];
    
    let opticalFlowForce = createVector(0, 0);
    
    if (flow) {
      let closestZone = flow.zones[0];
      let closestDist = dist(
        map(closestZone.x, 0, opticalFlow.width, 0, width),
        map(closestZone.y, 0, opticalFlow.height, 0, height),
        particle.position.x,
        particle.position.y
      );
      
      // find the closest optical flow zone
      for (let j = 1; j < flow.zones.length; j++) {
        let zone = flow.zones[j];
        let zoneDist = dist(
          map(zone.x, 0, opticalFlow.width, 0, width), 
          map(zone.y, 0, opticalFlow.height, 0, height),
          particle.position.x,
          particle.position.y
        );
        
        if (zoneDist < closestDist) {
          closestZone = zone;
          closestDist = zoneDist;
        }
      }
      
      opticalFlowForce.x = closestZone.u * flowScaleFactor;
      opticalFlowForce.y = closestZone.v * flowScaleFactor;
    }
    
    particle.applyForce(opticalFlowForce);
    particle.update();
    particle.applyFriction(0.95);
    particle.display();
  }
}

function takeScreenshot () {
  save('myCanvas.jpg');
}

function gogh () {
  for (let i = 0; i < 100; i++) {
    if ( i < 20) {
      particles[i].color = color(26, 66, 91, 75);
    } else if ( i < 40) {
      particles[i].color = color(198, 202, 116, 75); 
    } else if ( i < 60) {
      particles[i].color = color(224, 179, 5, 75); 
    } else if ( i < 80) {
      particles[i].color = color(57, 137, 185, 75);
    } else {
      particles[i].color = color(121, 164, 158, 75); 
    }
  }
}

function lava () {
  for(let i = 0; i < 100; i++) {
    particles[i].color = color(255, random(255), random(255), 75);
  }
}

function keyPressed() {
  if (key === ' ') {
    debug = !debug;
  }
}