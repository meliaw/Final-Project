class Particle {
  constructor(x, y, mass = 1, displaySize = 10) {
    this.position = createVector(x, y);
    this.velocity = createVector(0, 0);
    this.acceleration = createVector(0, 0);
    this.color = (0);
    this.mass = mass;
    this.displaySize = displaySize;
    this.angle = 0;
    this.fluctuate = 0;
  }
  
  applyForce(force) {
    let f = p5.Vector.div(force, this.mass);
    this.acceleration.add(f);
  }
  
  applyFriction(friction) {
    this.velocity.mult(friction);
  }
  
  update() {
    this.velocity.add(this.acceleration);
    this.position.add(this.velocity);
    this.acceleration.mult(0);
    
    // makes particles 
    this.fluctuate = (sin(this.angle + PI / 2) * this.displaySize) / 2 + this.displaySize / 2;
    this.angle += 0.02;
  }
  
  display() {
    let leftWall = -50;
    let rightWall = windowWidth + 50;
    let topWall = -50;
    let bottomWall = windowHeight + 50;
    
    let xConstrain = constrain(this.position.x, leftWall, rightWall);
    let yConstrain = constrain(this.position.y, topWall, bottomWall);
    
    fill(this.color);
    stroke(this.color);
    //ellipse(this.position.x, this.position.y, this.displaySize, this.displaySize);
    ellipse(xConstrain, yConstrain, this.fluctuate, this.fluctuate);
  }
}